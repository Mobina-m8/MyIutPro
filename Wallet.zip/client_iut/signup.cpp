#include "SignUp.h"
#include "ui_SignUp.h"
#include "ClientServerCommunication.h"
#include <QJsonObject>
#include <QMessageBox>

SignUp::SignUp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SignUp),
    connector(new ClientServerCommunication(this)) // ساخت شیء برای ارتباط با سرور
{
    ui->setupUi(this);

    // اتصال دکمه‌ها به اسلات‌های مربوطه
    connect(ui->pushButton, &QPushButton::clicked, this, &SignUp::onSignUpButtonClicked);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &SignUp::onBackButtonClicked);

    // اتصال سیگنال‌های ClientServerCommunication به اسلات‌ها
    connect(connector, &ClientServerCommunication::signUpResponseReceived, this, &SignUp::handleSignUpResponse);
    connect(connector, &ClientServerCommunication::errorOccurred, this, &SignUp::handleError);
}

SignUp::~SignUp()
{
    delete ui;
}

void SignUp::onSignUpButtonClicked()
{
    // گرفتن اطلاعات کاربر از ویجت‌ها
    QString email = ui->textEdit->toPlainText().trimmed();
    QString password = ui->textEdit_2->toPlainText();
    QString name = ui->textEdit_3->toPlainText().trimmed();
    QString phone = ui->textEdit_4->toPlainText().trimmed();
    QString address = ui->textEdit_5->toPlainText().trimmed();
    QString inviteCode = ui->textEdit_6->toPlainText().trimmed();

    // بررسی اولیه برای فیلدهای اجباری
    if (email.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Email and password are required!");
        return;
    }

    // ساختن JSON برای ارسال به سرور
    QJsonObject requestData;
    requestData["email"] = email;
    requestData["password"] = password;
    requestData["name"] = name;
    requestData["phone"] = phone;
    requestData["address"] = address;
    if (!inviteCode.isEmpty()) {
        requestData["inviteCode"] = inviteCode; // فقط در صورت پر شدن ارسال شود
    }

    // ارسال درخواست ثبت نام به سرور
    connector->signUp(requestData);
}

void SignUp::onBackButtonClicked()
{
    this->reject(); // فرم را ببندید و به فرم اصلی بازگردید
}

void SignUp::handleSignUpResponse(const QJsonObject &response)
{
    if (response.contains("success") && response["success"].toBool()) {
        QMessageBox::information(this, "SignUp Successful", "Your account has been created successfully!");
        this->accept(); // فرم را ببندید
    } else {
        QString error = response.value("message").toString("SignUp failed!");
        QMessageBox::critical(this, "SignUp Failed", error);
    }
}

void SignUp::handleError(const QString &error)
{
    QMessageBox::critical(this, "Error", error);
}
