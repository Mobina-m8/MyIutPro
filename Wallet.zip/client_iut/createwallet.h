#ifndef CREATEWALLET_H
#define CREATEWALLET_H

#include <QDialog>
#include <QJsonObject>
#include "ClientServerCommunication.h"

namespace Ui {
class CreateWallet;
}

class CreateWallet : public QDialog
{
    Q_OBJECT

public:
    explicit CreateWallet(QWidget *parent = nullptr);
    ~CreateWallet();

private slots:
    void onCreateWalletButtonClicked();
    void onBackButtonClicked();
    void handleWalletCreationResponse(const QJsonObject &response);
    void handleError(const QString &error);

private:
    Ui::CreateWallet *ui;
    ClientServerCommunication *connector;
};

#endif // CREATEWALLET_H
