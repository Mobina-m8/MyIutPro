#include "CreateWallet.h"
#include "ui_CreateWallet.h"
#include "ClientServerCommunication.h"
#include <QMessageBox>
#include <QJsonObject>

CreateWallet::CreateWallet(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CreateWallet),
    connector(new ClientServerCommunication(this)) // ایجاد شیء برای ارتباط با سرور
{
    ui->setupUi(this);

    // اتصال دکمه به متد مربوطه
    connect(ui->pushButton, &QPushButton::clicked, this, &CreateWallet::onCreateWalletButtonClicked);
    connect(ui->pushButton_2, &QPushButton::clicked, this, &CreateWallet::onBackButtonClicked);

    // اتصال سیگنال‌های ClientServerCommunication به اسلات‌ها
    connect(connector, &ClientServerCommunication::walletCreationResponseReceived, this, &CreateWallet::handleWalletCreationResponse);
    connect(connector, &ClientServerCommunication::errorOccurred, this, &CreateWallet::handleError);
}

CreateWallet::~CreateWallet()
{
    delete ui;
}

void CreateWallet::onCreateWalletButtonClicked()
{
    // دریافت نام ولت از textEdit
    QString walletName = ui->textEdit->toPlainText().trimmed();

    // بررسی اینکه فیلد خالی نباشد
    if (walletName.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Wallet name cannot be empty!");
        return;
    }

    // ساختن JSON برای درخواست
    QJsonObject requestData;
    requestData["walletName"] = walletName;

    // ارسال درخواست به سرور
    connector->createWallet(requestData);
}

void CreateWallet::onBackButtonClicked()
{
    this->reject(); // فرم را ببندید و به فرم اصلی بازگردید
}

void CreateWallet::handleWalletCreationResponse(const QJsonObject &response)
{
    if (response.contains("success") && response["success"].toBool()) {
        QMessageBox::information(this, "Wallet Created", "Your wallet has been created successfully!");
        this->accept(); // فرم را ببندید
    } else {
        QString error = response.value("message").toString("Failed to create wallet!");
        QMessageBox::critical(this, "Error", error);
    }
}

void CreateWallet::handleError(const QString &error)
{
    QMessageBox::critical(this, "Error", error);
}
