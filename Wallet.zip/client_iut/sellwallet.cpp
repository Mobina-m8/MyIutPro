#include "sellwallet.h"
#include "ui_sellwallet.h"

sellwallet::sellwallet(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::sellwallet)
{
    ui->setupUi(this);
}

sellwallet::~sellwallet()
{
    delete ui;
}
