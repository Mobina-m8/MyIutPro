#include "SignIn.h"
#include <QMessageBox>
#include "ClientServerCommunication.h"
#include "ui_SignIn.h"

SignIn::SignIn(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::SignIn)
    , connector(new ClientServerCommunication(this)) // نمونه کلاس ارتباط با سرور
{
    ui->setupUi(this);

    // اتصال سیگنال‌ها و اسلات‌ها برای مدیریت پاسخ سرور
    connect(connector,
            &ClientServerCommunication::loginResponseReceived,
            this,
            &SignIn::handleLoginResponse);
    connect(connector, &ClientServerCommunication::errorOccurred, this, &SignIn::handleError);
}

SignIn::~SignIn()
{
    delete ui;
}

// متد مدیریت کلیک روی دکمه لاگین
void SignIn::onLoginButtonClicked()
{
    // گرفتن اطلاعات یوزرنیم و پسورد از تکست‌باکس‌ها
    QString username = ui->textEdit->toPlainText();
    QString password = ui->textEdit_2->toPlainText();

    // بررسی اینکه فیلدها خالی نباشند
    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Login Failed", "Username or password cannot be empty.");
        return;
    }

    // ارسال درخواست لاگین به سرور
    connector->login(username, password);
}

// مدیریت پاسخ موفق لاگین از سرور
void SignIn::handleLoginResponse(const QJsonObject &response)
{
    if (response.contains("success") && response["success"].toBool()) {
        QMessageBox::information(this,
                                 "Login Successful",
                                 "Welcome, " + ui->textEdit->toPlainText() + "!");
        accept(); // بستن فرم لاگین در صورت موفقیت
    } else {
        QString errorMessage = response.value("message").toString(
            "Login failed. Please try again.");
        QMessageBox::warning(this, "Login Failed", errorMessage);
    }
}

// مدیریت خطاهای ارتباط با سرور
void SignIn::handleError(const QString &error)
{
    QMessageBox::critical(this, "Error", "An error occurred: " + error);
}
