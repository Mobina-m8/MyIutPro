#ifndef SELLWALLET_H
#define SELLWALLET_H

#include <QDialog>

namespace Ui {
class sellwallet;
}

class sellwallet : public QDialog
{
    Q_OBJECT

public:
    explicit sellwallet(QWidget *parent = nullptr);
    ~sellwallet();

private:
    Ui::sellwallet *ui;
};

#endif // SELLWALLET_H
