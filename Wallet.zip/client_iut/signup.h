#ifndef SIGNUP_H
#define SIGNUP_H

#include <QDialog>
#include "ClientServerCommunication.h"

namespace Ui {
class SignUp;
}

class SignUp : public QDialog
{
    Q_OBJECT

public:
    explicit SignUp(QWidget *parent = nullptr);
    ~SignUp();

private:
    Ui::SignUp *ui;
    ClientServerCommunication *connector; // برای ارتباط با سرور

private slots:
    void onSignUpButtonClicked();      // برای ثبت نام
    void onBackButtonClicked();        // برای بازگشت به فرم اصلی
    void handleSignUpResponse(const QJsonObject &response); // مدیریت پاسخ ثبت نام
    void handleError(const QString &error); // مدیریت خطاها
};

#endif // SIGNUP_H
