#include "buywallet.h"
#include "ui_buywallet.h"

buywallet::buywallet(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::buywallet)
{
    ui->setupUi(this);
}

buywallet::~buywallet()
{
    delete ui;
}
