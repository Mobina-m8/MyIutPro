#ifndef CLIENTSERVERCOMMUNICATION_H
#define CLIENTSERVERCOMMUNICATION_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonObject>
#include <QJsonDocument>

class ClientServerCommunication : public QObject
{
    Q_OBJECT

public:
    explicit ClientServerCommunication(QObject *parent = nullptr);

    // متدهای ارسال درخواست به سرور
    void login(const QString &email, const QString &password);
    void signUp(const QJsonObject &userData);
    void createWallet(const QJsonObject &walletData);
    void performTransaction(const QJsonObject &transactionData);

signals:
    // سیگنال‌ها برای ارسال نتیجه به فرم
    void loginResponseReceived(const QJsonObject &response);
    void signUpResponseReceived(const QJsonObject &response);
    void walletCreationResponseReceived(const QJsonObject &response);
    void transactionResponseReceived(const QJsonObject &response);
    void errorOccurred(const QString &errorMessage);

private slots:
    // مدیریت پاسخ سرور
    void handleNetworkReply(QNetworkReply *reply);

private:
    QNetworkAccessManager *networkManager;

    // متد کمکی برای ارسال درخواست
    void sendRequest(const QString &endpoint, const QJsonObject &data, const QString &requestType);
};

#endif // CLIENTSERVERCOMMUNICATION_H
