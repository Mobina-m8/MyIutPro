#include "ClientServerCommunication.h"
#include <QNetworkRequest>
#include <QUrl>
#include <QDebug>

ClientServerCommunication::ClientServerCommunication(QObject *parent)
    : QObject(parent), networkManager(new QNetworkAccessManager(this))
{
    connect(networkManager, &QNetworkAccessManager::finished, this, &ClientServerCommunication::handleNetworkReply);
}

// متد لاگین
void ClientServerCommunication::login(const QString &email, const QString &password)
{
    QJsonObject requestData;
    requestData["email"] = email;
    requestData["password"] = password;
    sendRequest("http://127.0.0.1:8080/api/login", requestData, "POST");
}

// متد ثبت‌نام
void ClientServerCommunication::signUp(const QJsonObject &userData)
{
    sendRequest("http://127.0.0.1:8080/api/signup", userData, "POST");
}

// متد ایجاد ولت
void ClientServerCommunication::createWallet(const QJsonObject &walletData)
{
    sendRequest("http://127.0.0.1:8080/api/wallet/create", walletData, "POST");
}

// متد انجام تراکنش
void ClientServerCommunication::performTransaction(const QJsonObject &transactionData)
{
    sendRequest("http://127.0.0.1:8080/api/transaction", transactionData, "POST");
}

// متد ارسال درخواست به سرور
void ClientServerCommunication::sendRequest(const QString &endpoint, const QJsonObject &data, const QString &requestType)
{
    QUrl url(endpoint);  // آدرس URL
    QNetworkRequest request(url);  // ایجاد شیء QNetworkRequest
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QByteArray requestBody = QJsonDocument(data).toJson();

    if (requestType == "POST") {
        networkManager->post(request, requestBody);  // ارسال درخواست POST
    } else if (requestType == "GET") {
        networkManager->get(request);  // ارسال درخواست GET
    } else {
        qWarning() << "Unsupported request type:" << requestType;
    }
}

// مدیریت پاسخ دریافتی از سرور
void ClientServerCommunication::handleNetworkReply(QNetworkReply *reply)
{
    if (reply->error() != QNetworkReply::NoError) {
        emit errorOccurred(reply->errorString());
        reply->deleteLater();
        return;
    }

    QByteArray responseData = reply->readAll();
    QJsonDocument jsonResponse = QJsonDocument::fromJson(responseData);
    QJsonObject responseObj = jsonResponse.object();

    // مدیریت پاسخ بر اساس آدرس URL
    QString url = reply->url().toString();
    if (url.contains("login")) {
        emit loginResponseReceived(responseObj);
    } else if (url.contains("signup")) {
        emit signUpResponseReceived(responseObj);
    } else if (url.contains("wallet/create")) {
        emit walletCreationResponseReceived(responseObj);
    } else if (url.contains("transaction")) {
        emit transactionResponseReceived(responseObj);
    }

    reply->deleteLater();
}
