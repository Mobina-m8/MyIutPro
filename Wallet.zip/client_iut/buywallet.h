#ifndef BUYWALLET_H
#define BUYWALLET_H

#include <QDialog>

namespace Ui {
class buywallet;
}

class buywallet : public QDialog
{
    Q_OBJECT

public:
    explicit buywallet(QWidget *parent = nullptr);
    ~buywallet();

private:
    Ui::buywallet *ui;
};

#endif // BUYWALLET_H
