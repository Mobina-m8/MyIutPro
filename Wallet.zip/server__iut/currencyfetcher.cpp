#include <QTimer>
#include <QMap>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QString>
#include <QJsonDocument>
#include <QDebug>

class CurrencyFetcher : public QObject {
    Q_OBJECT
public:
    CurrencyFetcher() {
        // راه‌اندازی تایمر برای به‌روزرسانی هر 10 دقیقه یکبار
        updateTimer.setInterval(600000); // 600,000 میلی‌ثانیه = 10 دقیقه
        connect(&updateTimer, &QTimer::timeout, this, &CurrencyFetcher::fetchPrices);
        updateTimer.start();
    }

    // دریافت قیمت ارزها از API
    void fetchPrices() {
        QNetworkRequest request;
        request.setUrl(QUrl("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana,dogecoin,shiba-inu,tether&vs_currencies=usdt"));

        QNetworkReply* reply = networkManager.get(request);

        connect(reply, &QNetworkReply::finished, this, &CurrencyFetcher::handleResponse);
    }

    // مدیریت پاسخ از API
    void handleResponse() {
        QNetworkReply* reply = qobject_cast<QNetworkReply*>(sender());
        if (reply->error() != QNetworkReply::NoError) {
            qDebug() << "Error fetching prices:" << reply->errorString();
            reply->deleteLater();
            return;
        }

        // پردازش داده‌های دریافت شده
        QByteArray data = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(data);
        QJsonObject json = doc.object();

        // ذخیره قیمت‌ها
        for (const QString& coin : json.keys()) {
            double price = json[coin].toObject()["usdt"].toDouble();
            updateCurrencyPrice(coin, price);
        }

        reply->deleteLater();
    }

    // به‌روزرسانی قیمت ارزها در سیستم
    void updateCurrencyPrice(const QString& currencyId, double price) {
        currencyPrices[currencyId] = price;
        qDebug() << "Updated price for" << currencyId << ": $" << price;
    }

    // گرفتن قیمت ارزها
    double getCurrencyPrice(const QString& currencyId) const {
        return currencyPrices.contains(currencyId) ? currencyPrices[currencyId] : 0.0;
    }

private:
    QMap<QString, double> currencyPrices; // نگهداری قیمت ارزها
    QTimer updateTimer; // تایمر برای به‌روزرسانی خودکار
    QNetworkAccessManager networkManager; // مدیر درخواست‌های شبکه
};
