#ifndef USEREXCEPTION_H
#define USEREXCEPTION_H

#include <exception>
#include <QString>

class UserException : public std::exception {
public:
    explicit UserException(const QString &message);
    const char *what() const noexcept override;

private:
    QString errorMessage;
};

#endif // USEREXCEPTION_H
