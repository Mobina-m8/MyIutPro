#include <QString>
#include <QRegularExpression>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include "UserException.h"

class UserValidation {
public:
    UserValidation(QSqlDatabase &db) : database(db) {}

    // اعتبارسنجی داده‌های کاربر
    bool validateUserData(const QString &email, const QString &password, const QString &phone) {
        validateEmail(email);
        validatePassword(password);

        if (!phone.isEmpty()) {
            validatePhone(phone);
        }

        return true;
    }

    // بررسی ایمیل
    void validateEmail(const QString &email) {
        QRegularExpression emailRegex(R"((\w+)(\.\w+)*@(\w+)(\.\w+)+)");
        QRegularExpressionMatch match = emailRegex.match(email);

        if (!match.hasMatch()) {
            throw UserException("Invalid email format");
        }

        if (emailExists(email)) {
            throw UserException("Email already exists");
        }
    }

    // بررسی قدرت پسورد
    void validatePassword(const QString &password) {
        if (password.length() < 8) {
            throw UserException("Password must be at least 8 characters long");
        }

        QRegularExpression upperCaseRegex("[A-Z]");
        QRegularExpression lowerCaseRegex("[a-z]");
        QRegularExpression digitRegex("\\d");
        QRegularExpression specialCharRegex("[!@#$%^&*(),.?\":{}|<>]");

        if (!upperCaseRegex.match(password).hasMatch() ||
            !lowerCaseRegex.match(password).hasMatch() ||
            !digitRegex.match(password).hasMatch() ||
            !specialCharRegex.match(password).hasMatch()) {
            throw UserException("Password must contain upper case, lower case, digit, and special character");
        }
    }

    // بررسی شماره تلفن
    void validatePhone(const QString &phone) {
        QRegularExpression phoneRegex("^\\d{10,15}$");
        QRegularExpressionMatch match = phoneRegex.match(phone);

        if (!match.hasMatch()) {
            throw UserException("Invalid phone number");
        }
    }

private:
    QSqlDatabase database;

    // بررسی وجود ایمیل در دیتابیس
    bool emailExists(const QString &email) {
        QSqlQuery query(database);
        query.prepare("SELECT COUNT(*) FROM users WHERE email = :email");
        query.bindValue(":email", email);

        if (query.exec() && query.next()) {
            return query.value(0).toInt() > 0;
        }

        throw UserException("Failed to check email existence: " + query.lastError().text());
    }
};
