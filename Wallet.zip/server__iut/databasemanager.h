#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QObject>
#include <QString>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QVariantList>
#include <QDebug>

class DatabaseManager : public QObject
{
    Q_OBJECT

public:
    explicit DatabaseManager(QObject *parent = nullptr);
    ~DatabaseManager();

    // متدهای مدیریت کاربران
    bool addUser(const QString &email, const QString &passwordHash, const QString &name,
                 const QString &address, const QString &phoneNumber, const QString &inviteCode, int level, QString &errorMessage);
    bool validateUser(const QString &email, const QString &passwordHash, QString &errorMessage);

    // متدهای مدیریت ولت
    bool addWallet(const QString &name, const QString &address, const QString &userEmail, const QStringList &mnemonicWords, QString &errorMessage);
    bool updateWalletBalance(const QString &walletAddress, const QString &currency, double amount, QString &errorMessage);

    // متدهای مدیریت تراکنش
    bool addTransaction(const QString &fromWallet, const QString &toWallet, const QString &currency, double amount, QString &errorMessage);

    // متدهای مدیریت ارزها
    QStringList getAllCurrencies(QString &errorMessage);

    // متد کمکی
    bool initializeDatabase(QString &errorMessage);

private:
    QSqlDatabase db;

    // متدهای داخلی
    bool executeQuery(const QString &queryStr, const QVariantList &bindings, QString &errorMessage);
};

#endif // DATABASEMANAGER_H
