#include <QSqlQuery>
#include <QSqlError>
#include "WalletManager.h"

// گرفتن کیف پول کاربر
Wallet *WalletManager::getWalletForUser(const QString &userId) {
    return &wallets[userId]; // بازگشت کیف پول برای کاربر مشخص
}

// اضافه کردن یا به‌روزرسانی کیف پول یک کاربر
void WalletManager::createOrUpdateWallet(const QString &userId) {
    if (!wallets.contains(userId)) {
        wallets[userId] = Wallet(); // ایجاد کیف پول جدید برای کاربر
    }
}

Wallet* WalletManager::getWalletById(int walletId) {
    QSqlQuery query;
    query.prepare(R"(
        SELECT id, user_id, name, address, seed_words, btc_balance, eth_balance, sol_balance,
               doge_balance, shib_balance, usdt_balance
        FROM wallets
        WHERE id = :wallet_id
    )");
    query.bindValue(":wallet_id", walletId);

    if (query.exec() && query.next()) {
        // ایجاد یک شی Wallet جدید و مقداردهی به آن با داده‌های گرفته شده از پایگاه داده
        Wallet* wallet = new Wallet();
        wallet->setWalletId(query.value("id").toInt());
        wallet->setUserId(query.value("user_id").toInt());
        wallet->setName(query.value("name").toString());
        wallet->setAddress(query.value("address").toString());
        wallet->setSeedWords(query.value("seed_words").toString());
        wallet->setBtcBalance(query.value("btc_balance").toDouble());
        wallet->setEthBalance(query.value("eth_balance").toDouble());
        wallet->setSolBalance(query.value("sol_balance").toDouble());
        wallet->setDogeBalance(query.value("doge_balance").toDouble());
        wallet->setShibBalance(query.value("shib_balance").toDouble());
        wallet->setUsdtBalance(query.value("usdt_balance").toDouble());

        return wallet;
    } else {
        qDebug() << "Error retrieving wallet:" << query.lastError().text();
        return nullptr;  // در صورت عدم یافتن کیف پول
    }
}
