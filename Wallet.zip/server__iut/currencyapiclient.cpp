#include <QString>
#include <QMap>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QDebug>
#include <QCoreApplication>
#include "UserException.h"

class CurrencyApiClient : public QObject {
    Q_OBJECT

public:
    explicit CurrencyApiClient(QObject *parent = nullptr) : QObject(parent), networkManager(new QNetworkAccessManager(this)) {}

    // دریافت قیمت لحظه‌ای ارزها
    void fetchLivePrices(const QStringList &currencyIds) {
        QString ids = currencyIds.join(",");
        QString url = "https://api.coingecko.com/api/v3/simple/price?ids=" + ids + "&vs_currencies=usdt";
        QNetworkRequest request;
        request.setUrl(QUrl(url));

        QNetworkReply *reply = networkManager->get(request);
        connect(reply, &QNetworkReply::finished, this, &CurrencyApiClient::onFetchLivePricesFinished);
        connect(reply, &QNetworkReply::errorOccurred, this, &CurrencyApiClient::onError);
    }

    // دریافت اطلاعات جزئی یک ارز
    void fetchCurrencyDetails(const QString &currencyId) {
        QString url = "https://api.coingecko.com/api/v3/coins/" + currencyId;
        QNetworkRequest request;
        request.setUrl(QUrl(url));

        QNetworkReply *reply = networkManager->get(request);
        connect(reply, &QNetworkReply::finished, this, &CurrencyApiClient::onFetchCurrencyDetailsFinished);
        connect(reply, &QNetworkReply::errorOccurred, this, &CurrencyApiClient::onError);
    }

private slots:
    void onFetchLivePricesFinished() {
        QNetworkReply *reply = qobject_cast<QNetworkReply *>(sender());
        if (reply->error() == QNetworkReply::NoError) {
            QJsonDocument jsonResponse = QJsonDocument::fromJson(reply->readAll());
            QJsonObject jsonObject = jsonResponse.object();
            QMap<QString, QString> prices;

            for (const QString &key : jsonObject.keys()) {
                prices[key] = QString::number(jsonObject[key].toObject()["usdt"].toDouble());
            }

            // اینجا میتوانید داده‌های prices را به جای دیگری ارسال کنید یا نمایش دهید
            qDebug() << prices;
        } else {
            QString errorMessage = "Failed to fetch live prices: " + reply->errorString();
            throw UserException(errorMessage);
        }

        reply->deleteLater();
    }

    void onFetchCurrencyDetailsFinished() {
        QNetworkReply *reply = qobject_cast<QNetworkReply *>(sender());
        if (reply->error() == QNetworkReply::NoError) {
            QJsonDocument jsonResponse = QJsonDocument::fromJson(reply->readAll());
            QJsonObject jsonObject = jsonResponse.object();

            QMap<QString, QString> details;
            details["id"] = jsonObject["id"].toString();
            details["name"] = jsonObject["name"].toString();
            details["symbol"] = jsonObject["symbol"].toString();
            details["description"] = jsonObject["description"].toObject()["en"].toString();
            details["current_price"] = QString::number(jsonObject["market_data"].toObject()["current_price"].toObject()["usdt"].toDouble());

            // اینجا میتوانید داده‌های details را به جای دیگری ارسال کنید یا نمایش دهید
            qDebug() << details;
        } else {
            QString errorMessage = "Failed to fetch currency details: " + reply->errorString();
            throw UserException(errorMessage);
        }

        reply->deleteLater();
    }

    void onError(QNetworkReply::NetworkError code) {
        qDebug() << "Network error occurred:" << code;
    }

private:
    QNetworkAccessManager *networkManager;
};
