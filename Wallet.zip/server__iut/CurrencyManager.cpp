#include <QString>
#include <QMap>
#include <QDebug>
#include "currencyfetcher.h"  // فایل مربوط به کلاس CurrencyFetcher که برای به‌روزرسانی خودکار استفاده می‌شود

class CryptoManager : public QObject {
    Q_OBJECT
public:
    // سازنده کلاس CryptoManager
    CryptoManager() {
        currencyFetcher = new CurrencyFetcher(); // ساخت نمونه از کلاس CurrencyFetcher
    }

    // دریافت قیمت لحظه‌ای ارز بر اساس شناسه ارز
    double getPrice(const QString& currencyId) {
        double price = currencyFetcher->getCurrencyPrice(currencyId); // دریافت قیمت از CurrencyFetcher
        if (price == 0.0) {
            qDebug() << "Price for" << currencyId << "not available";
        }
        return price;
    }

    // تابعی برای انجام تراکنش خرید/فروش ارز
    bool buyCurrency(const QString& userId, const QString& currencyId, double amount) {
        double price = getPrice(currencyId);
        if (price == 0.0) {
            qDebug() << "Unable to fetch price for" << currencyId;
            return false;
        }

        double totalCost = price * amount;

        // اینجا می‌توانید منطق خرید ارز را اضافه کنید
        // مثل بررسی موجودی کاربر، انجام تراکنش و بروز کردن موجودی کیف پول
        qDebug() << "Buying" << amount << currencyId << "for" << totalCost << "USDT";

        // فرض می‌کنیم تراکنش با موفقیت انجام شد
        return true;
    }

    // تابعی برای انجام تراکنش فروش ارز
    bool sellCurrency(const QString& userId, const QString& currencyId, double amount) {
        double price = getPrice(currencyId);
        if (price == 0.0) {
            qDebug() << "Unable to fetch price for" << currencyId;
            return false;
        }

        double totalValue = price * amount;

        // اینجا می‌توانید منطق فروش ارز را اضافه کنید
        // مثل بررسی موجودی ارز و انجام تراکنش فروش
        qDebug() << "Selling" << amount << currencyId << "for" << totalValue << "USDT";

        // فرض می‌کنیم تراکنش با موفقیت انجام شد
        return true;
    }

    // تابعی برای انتقال ارز به کیف پول دیگر
    bool transferCurrency(const QString& senderId, const QString& receiverId, const QString& currencyId, double amount) {
        double price = getPrice(currencyId);
        if (price == 0.0) {
            qDebug() << "Unable to fetch price for" << currencyId;
            return false;
        }

        // بررسی موجودی کیف پول و انجام تراکنش انتقال
        qDebug() << "Transferring" << amount << currencyId << "from" << senderId << "to" << receiverId;

        // فرض می‌کنیم تراکنش با موفقیت انجام شد
        return true;
    }

    // تابعی برای دریافت اطلاعات کامل یک ارز (مثل اطلاعات از API)
    void fetchCurrencyDetails(const QString& currencyId) {
        qDebug() << "Fetching detailed information for" << currencyId;
        // اینجا می‌توانید از CurrencyFetcher استفاده کنید که اطلاعات کامل ارز را از API بگیرد
        // مثلاً از API CoinGecko برای دریافت جزئیات بیشتر ارزها
    }

private:
    CurrencyFetcher* currencyFetcher; // ارجاع به CurrencyFetcher که برای به‌روزرسانی خودکار قیمت‌ها استفاده می‌شود
};
