#ifndef CURRENCYVALIDATION_H
#define CURRENCYVALIDATION_H

#include <QString>
#include "UserException.h"

class CurrencyValidation {
public:
    static void validateCurrency(const QString &currency);
};

#endif // CURRENCYVALIDATION_H
