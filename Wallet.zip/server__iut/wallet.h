#ifndef WALLET_H
#define WALLET_H

#include <QString>
#include <QMap>

class Wallet {
public:
    explicit Wallet(int walletId = -1, int userId = -1, const QString &name = "", const QString &address = "",
                    const QString &seedWords = "");

    // گرفتن موجودی ارز از کیف پول
    double getBalance(const QString &currencyId) const;

    // به‌روزرسانی موجودی ارز در کیف پول
    void updateBalance(const QString &currencyId, double amount);

    // تنظیمات متدهای Getters و Setters
    void setWalletId(int id) { walletId = id; }
    int getWalletId() const { return walletId; }

    void setUserId(int id) { userId = id; }
    int getUserId() const { return userId; }

    void setName(const QString &walletName) { name = walletName; }
    const QString& getName() const { return name; }

    void setAddress(const QString &walletAddress) { address = walletAddress; }
    const QString& getAddress() const { return address; }

    void setSeedWords(const QString &words) { seedWords = words; }
    const QString& getSeedWords() const { return seedWords; }

    void setBtcBalance(double balance) { balances["btc"] = balance; }
    double getBtcBalance() const { return getBalance("btc"); }

    void setEthBalance(double balance) { balances["eth"] = balance; }
    double getEthBalance() const { return getBalance("eth"); }

    void setSolBalance(double balance) { balances["sol"] = balance; }
    double getSolBalance() const { return getBalance("sol"); }

    void setDogeBalance(double balance) { balances["doge"] = balance; }
    double getDogeBalance() const { return getBalance("doge"); }

    void setShibBalance(double balance) { balances["shib"] = balance; }
    double getShibBalance() const { return getBalance("shib"); }

    void setUsdtBalance(double balance) { balances["usdt"] = balance; }
    double getUsdtBalance() const { return getBalance("usdt"); }

private:
    int walletId;
    int userId;
    QString name;
    QString address;
    QString seedWords;
    QMap<QString, double> balances; // ذخیره موجودی ارزها
};

#endif // WALLET_H
