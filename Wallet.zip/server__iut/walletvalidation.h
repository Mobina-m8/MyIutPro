#ifndef WALLETVALIDATION_H
#define WALLETVALIDATION_H

#include <QString>
#include "UserException.h"

class WalletValidation {
public:
    static void validateWalletName(const QString &name);
    static void validateSufficientFunds(double balance, double amount);
};

#endif // WALLETVALIDATION_H
