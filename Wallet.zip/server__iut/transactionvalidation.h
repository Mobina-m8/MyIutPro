#ifndef TRANSACTIONVALIDATION_H
#define TRANSACTIONVALIDATION_H

#include <QString>
#include "WalletManager.h"
#include "UserException.h"

class TransactionValidation {
public:
    explicit TransactionValidation(WalletManager *walletManager) : walletManager(walletManager) {}

    // بررسی موجودی کافی برای خرید
    bool validatePurchase(int walletId, const QString &currencyId, double amount, double price);

    // بررسی موجودی کافی برای فروش
    bool validateSell(int walletId, const QString &currencyId, double amount);

    // بررسی موجودی کافی برای انتقال ارز
    bool validateTransfer(int walletId, const QString &currencyId, double amount);

private:
    WalletManager *walletManager;
};

#endif // TRANSACTIONVALIDATION_H
