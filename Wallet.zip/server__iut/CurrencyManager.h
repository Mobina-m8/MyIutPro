#ifndef CURRENCYMANAGER_H
#define CURRENCYMANAGER_H

#include <QObject>
#include <QMap>
#include "CurrencyApiClient.h"

class CurrencyManager : public QObject {
    Q_OBJECT

public:
    explicit CurrencyManager(CurrencyApiClient *apiClient, QObject *parent = nullptr);
    QMap<QString, double> getCurrentPrices();
    QString getCurrencyDetails(const QString &currency);

private:
    CurrencyApiClient *apiClient;
};

#endif // CURRENCYMANAGER_H
