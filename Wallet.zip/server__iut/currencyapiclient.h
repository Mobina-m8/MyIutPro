#ifndef CURRENCYAPICLIENT_H
#define CURRENCYAPICLIENT_H

#include <QObject>
#include <QStringList>
#include <QMap>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include "UserException.h"

class CurrencyApiClient : public QObject {
    Q_OBJECT

public:
    explicit CurrencyApiClient(QObject *parent = nullptr);

    // دریافت قیمت لحظه‌ای ارزها
    void fetchLivePrices(const QStringList &currencyIds);

    // دریافت اطلاعات جزئی یک ارز
    void fetchCurrencyDetails(const QString &currencyId);

private slots:
    void onFetchLivePricesFinished();
    void onFetchCurrencyDetailsFinished();
    void onError(QNetworkReply::NetworkError code);

private:
    QNetworkAccessManager *networkManager;
};

#endif // CURRENCYAPICLIENT_H
