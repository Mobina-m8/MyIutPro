#include "UserException.h"

// پیاده‌سازی سازنده کلاس
UserException::UserException(const QString &message) : errorMessage(message) {}

// پیاده‌سازی متد what() برای تبدیل QString به const char*
const char* UserException::what() const noexcept {
    return errorMessage.toStdString().c_str();  // تبدیل QString به string و سپس به const char*
}
