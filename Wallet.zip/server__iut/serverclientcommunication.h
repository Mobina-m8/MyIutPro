#ifndef SERVERCLIENTCOMMUNICATION_H
#define SERVERCLIENTCOMMUNICATION_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QUrl>

class ServerClientCommunication : public QObject {
    Q_OBJECT

public:
    explicit ServerClientCommunication(QObject *parent = nullptr);

    // ارسال داده‌ها برای ثبت نام
    void sendRegistrationData(const QString &username, const QString &password, const QString &email, const QString &name);

    // ارسال داده‌ها برای لاگین
    void sendLoginData(const QString &username, const QString &password);

    // ارسال داده‌ها برای تغییر رمز عبور
    void sendChangePasswordRequest(const QString &userId, const QString &oldPassword, const QString &newPassword);

    // ارسال داده‌ها برای ایجاد ولت
    void sendCreateWalletRequest(const QString &userId, const QString &walletName);

    // ارسال داده‌ها برای تراکنش
    void sendTransactionRequest(int senderWalletId, int receiverWalletId, double amount, const QString &currency);

private slots:
    // این متد وقتی داده‌ها از سرور دریافت می‌شود، فراخوانی می‌شود
    void onResponseReceived();

signals:
    // سیگنالی برای ارسال پاسخ دریافت شده به کلاینت
    void responseReceived(const QJsonObject &response);

private:
    QNetworkAccessManager *networkManager;  // مدیریت ارسال درخواست‌ها
};

#endif // SERVERCLIENTCOMMUNICATION_H
