#ifndef WALLETMANAGER_H
#define WALLETMANAGER_H

#include <QString>
#include <QMap>
#include "Wallet.h"

class WalletManager {
public:
    // گرفتن کیف پول کاربر
    Wallet *getWalletForUser(const QString &userId);

    // اضافه کردن یا به‌روزرسانی کیف پول یک کاربر
    void createOrUpdateWallet(const QString &userId);

    Wallet *getWalletById(int walletId);

private:
    QMap<QString, Wallet> wallets; // نگهداری تمام کیف پول‌های کاربران
};

#endif // WALLETMANAGER_H
