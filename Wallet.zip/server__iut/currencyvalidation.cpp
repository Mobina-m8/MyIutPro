#include <QString>
#include "UserException.h"

class CurrencyValidation {
public:
    // اعتبارسنجی شناسه ارز
    void validateCurrencyId(const QString &currencyId) {
        if (currencyId.isEmpty()) {
            throw UserException("Currency ID cannot be empty");
        }
    }
};
