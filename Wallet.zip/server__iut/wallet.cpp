#include "Wallet.h"

// سازنده کلاس
Wallet::Wallet(int walletId, int userId, const QString &name, const QString &address, const QString &seedWords)
    : walletId(walletId), userId(userId), name(name), address(address), seedWords(seedWords) {}

// گرفتن موجودی ارز از کیف پول
double Wallet::getBalance(const QString &currencyId) const {
    if (balances.contains(currencyId)) {
        return balances[currencyId];
    }
    return 0.0;
}

// به‌روزرسانی موجودی ارز در کیف پول
void Wallet::updateBalance(const QString &currencyId, double amount) {
    if (balances.contains(currencyId)) {
        balances[currencyId] += amount;
    } else {
        balances[currencyId] = amount;
    }
}
