#ifndef TRANSACTIONMANAGER_H
#define TRANSACTIONMANAGER_H

#include <QObject>
#include <QString>
#include "WalletManager.h"
#include "CurrencyManager.h"
#include "TransactionValidation.h"

class TransactionManager : public QObject {
    Q_OBJECT

public:
    explicit TransactionManager(WalletManager *walletManager, CurrencyManager *currencyManager, QObject *parent = nullptr);

    // متد برای خرید ارز (خرید همیشه به USDT است)
    bool purchaseCurrency(int walletId, const QString &currencyId, double amount, double price);

    // متد برای فروش ارز
    bool sellCurrency(int walletId, const QString &currencyId, double amount, double price);

    // متد برای انتقال ارز
    bool transferCurrency(int fromWalletId, int toWalletId, const QString &currencyId, double amount);

private:
    void recordTransaction(int walletId, const QString &type, const QString &currencyId, double amount, double price, const QString &targetWalletAddress);

    WalletManager *walletManager;         // مدیریت کیف پول‌ها
    CurrencyManager *currencyManager;     // مدیریت ارزها
    TransactionValidation *validation;    // اعتبارسنجی تراکنش‌ها
};

#endif // TRANSACTIONMANAGER_H
