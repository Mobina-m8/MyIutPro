#ifndef USERVALIDATION_H
#define USERVALIDATION_H

#include <QString>
#include <QSqlDatabase>

class UserValidation {
public:
    explicit UserValidation(QSqlDatabase &db); // سازنده‌ای که دیتابیس را می‌پذیرد

    bool validateUserData(const QString &email, const QString &password, const QString &phone);
    void validateEmail(const QString &email);
    void validatePassword(const QString &password);
    void validatePhone(const QString &phone);

private:
    QSqlDatabase database; // نگهداری شیء دیتابیس برای استفاده در متدها
};

#endif // USERVALIDATION_H
