#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

class DatabaseManager {
public:

    DatabaseManager(const QString &dbPath) {
        db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName(dbPath);

        if (!db.open()) {
            qDebug() << "Error opening database:" << db.lastError().text();
        } else {
            qDebug() << "Database opened successfully.";
            initializeTables();
        }
    }

    ~DatabaseManager() {
        if (db.isOpen()) {
            db.close();
        }
    }

    void initializeTables() {
        createUserTable();
        createWalletTable();
        createTransactionTable();
    }

    // متد برای دسترسی به اتصال به دیتابیس
    QSqlDatabase getDatabase() {
        return db;
    }

private:
    QSqlDatabase db;

    void createUserTable() {
        QSqlQuery query;
        QString sql = R"(
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                name TEXT,
                address TEXT,
                phone TEXT,
                invite_code TEXT,
                level INTEGER DEFAULT 0,
                is_verified INTEGER DEFAULT 0
            );
        )";

        if (!query.exec(sql)) {
            qDebug() << "Error creating users table:" << query.lastError().text();
        }
    }


    void createWalletTable() {
        QSqlQuery query;
        QString sql = R"(
            CREATE TABLE IF NOT EXISTS wallets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                address TEXT UNIQUE NOT NULL,
                seed_words TEXT NOT NULL,
                btc_balance REAL DEFAULT 0,
                eth_balance REAL DEFAULT 0,
                sol_balance REAL DEFAULT 0,
                doge_balance REAL DEFAULT 0,
                shib_balance REAL DEFAULT 0,
                usdt_balance REAL DEFAULT 0,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
        )";

        if (!query.exec(sql)) {
            qDebug() << "Error creating wallets table:" << query.lastError().text();
        }
    }

    void createTransactionTable() {
        QSqlQuery query;
        QString sql = R"(
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                wallet_id INTEGER NOT NULL,
                type TEXT NOT NULL, -- "transfer" or "trade"
                currency TEXT NOT NULL,
                amount REAL NOT NULL,
                target_wallet_address TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(wallet_id) REFERENCES wallets(id)
            );
        )";

        if (!query.exec(sql)) {
            qDebug() << "Error creating transactions table:" << query.lastError().text();
        }
    }
};
