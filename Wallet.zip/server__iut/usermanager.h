#ifndef USERMANAGER_H
#define USERMANAGER_H

#include <QObject>
#include <QString>
#include <QSqlDatabase>
#include "UserValidation.h"
#include "UserException.h"

class UserManager : public QObject {
    Q_OBJECT

public:
    explicit UserManager(QSqlDatabase &db, QObject *parent = nullptr);
    void registerUser(const QString &email, const QString &password, const QString &name,
                      const QString &address, const QString &phoneNumber, const QString &inviteCode);
    bool loginUser(const QString &email, const QString &password);
    bool changePassword(const QString &email, const QString &newPassword);
    bool verifyUser(const QString &email, const QString &verificationCode);

private:
    QSqlDatabase database;
    UserValidation validator;

    QString hashPassword(const QString &password);
    bool userExists(const QString &email);
};

#endif // USERMANAGER_H
