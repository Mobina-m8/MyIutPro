#ifndef CURRENCYFETCHER_H
#define CURRENCYFETCHER_H

#include <QObject>
#include <QTimer>
#include "CurrencyManager.h"

class CurrencyFetcher : public QObject {
    Q_OBJECT

public:
    explicit CurrencyFetcher(CurrencyManager *currencyManager, QObject *parent = nullptr);
    void startFetchingPrices(int intervalMs);

signals:
    void pricesUpdated(const QMap<QString, double> &prices);

private:
    CurrencyManager *currencyManager;
    QTimer *timer;

    void updatePrices();
};

#endif // CURRENCYFETCHER_H
