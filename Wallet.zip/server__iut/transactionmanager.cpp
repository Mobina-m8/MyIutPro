#include <QObject>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlError>
#include "TransactionValidation.h"
#include "UserException.h"
#include "WalletManager.h"
#include "CurrencyManager.h"

class TransactionManager : public QObject {
    Q_OBJECT

public:
    explicit TransactionManager(WalletManager *walletManager, CurrencyManager *currencyManager, QObject *parent = nullptr)
        : QObject(parent), walletManager(walletManager), currencyManager(currencyManager),
        validation(new TransactionValidation(walletManager)) {}

    // متد برای خرید ارز (خرید همیشه به USDT است)
    bool purchaseCurrency(int walletId, const QString &currencyId, double amount, double price) {
        try {
            validation->validatePurchase(walletId, currencyId, amount, price);

            // انجام خرید
            Wallet *wallet = walletManager->getWalletById(walletId);
            wallet->updateBalance("usdt", wallet->getBalance("usdt") - amount * price);
            wallet->updateBalance(currencyId, wallet->getBalance(currencyId) + amount);

            // ذخیره تراکنش
            recordTransaction(walletId, "purchase", currencyId, amount, price, "");
            return true;

        } catch (const UserException &e) {
            qDebug() << "Error during purchase:" << e.what();
            throw;
        }
    }

    // متد برای فروش ارز
    bool sellCurrency(int walletId, const QString &currencyId, double amount, double price) {
        try {
            validation->validateSell(walletId, currencyId, amount);

            // انجام فروش
            Wallet *wallet = walletManager->getWalletById(walletId);
            wallet->updateBalance(currencyId, wallet->getBalance(currencyId) - amount);
            wallet->updateBalance("usdt", wallet->getBalance("usdt") + amount * price);

            // ذخیره تراکنش
            recordTransaction(walletId, "sell", currencyId, amount, price, "");
            return true;

        } catch (const UserException &e) {
            qDebug() << "Error during sell:" << e.what();
            throw;
        }
    }

    // متد برای انتقال ارز
    bool transferCurrency(int fromWalletId, int toWalletId, const QString &currencyId, double amount) {
        try {
            validation->validateTransfer(fromWalletId, currencyId, amount);

            // انجام انتقال
            Wallet *fromWallet = walletManager->getWalletById(fromWalletId);
            Wallet *toWallet = walletManager->getWalletById(toWalletId);

            fromWallet->updateBalance(currencyId, fromWallet->getBalance(currencyId) - amount);
            toWallet->updateBalance(currencyId, toWallet->getBalance(currencyId) + amount);

            // ذخیره تراکنش
            recordTransaction(fromWalletId, "transfer", currencyId, amount, 0, toWallet->getAddress());
            return true;

        } catch (const UserException &e) {
            qDebug() << "Error during transfer:" << e.what();
            throw;
        }
    }

private:
    void recordTransaction(int walletId, const QString &type, const QString &currencyId, double amount, double price, const QString &targetWalletAddress) {
        QSqlQuery query;

        // درج تراکنش در جدول transactions
        query.prepare(R"(
            INSERT INTO transactions (wallet_id, type, currency, amount, target_wallet_address, timestamp)
            VALUES (:wallet_id, :type, :currency, :amount, :target_wallet_address, CURRENT_TIMESTAMP)
        )");

        query.bindValue(":wallet_id", walletId);
        query.bindValue(":type", type);
        query.bindValue(":currency", currencyId);
        query.bindValue(":amount", amount);
        query.bindValue(":target_wallet_address", targetWalletAddress);

        if (!query.exec()) {
            qDebug() << "Error inserting transaction into database:" << query.lastError().text();
        } else {
            qDebug() << "Transaction successfully recorded in database.";
        }
    }

    WalletManager *walletManager; // مدیریت کیف پول‌ها
    CurrencyManager *currencyManager; // مدیریت ارزها
    TransactionValidation *validation; // اعتبارسنجی تراکنش‌ها
};
