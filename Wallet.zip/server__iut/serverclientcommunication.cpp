#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QUrl>
#include <QDebug>

class ServerClientCommunication : public QObject {
    Q_OBJECT

public:
    // سازنده کلاس
    explicit ServerClientCommunication(QObject *parent = nullptr) : QObject(parent) {
        networkManager = new QNetworkAccessManager(this);
    }

    // ارسال داده به سرور برای ثبت نام
    void sendRegistrationData(const QString &username, const QString &password, const QString &email, const QString &name) {
        QUrl url("https://your-server-url.com/register"); // آدرس URL سرور برای ثبت نام
        QNetworkRequest request(url);
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

        // ساخت داده‌ها به صورت JSON
        QJsonObject json;
        json["username"] = username;
        json["password"] = password;
        json["email"] = email;
        json["name"] = name;

        QJsonDocument doc(json);
        QByteArray data = doc.toJson();

        // ارسال درخواست به سرور
        QNetworkReply *reply = networkManager->post(request, data);
        connect(reply, &QNetworkReply::finished, this, &ServerClientCommunication::onResponseReceived);
    }

    // ارسال داده به سرور برای لاگین
    void sendLoginData(const QString &username, const QString &password) {
        QUrl url("https://your-server-url.com/login"); // آدرس URL سرور برای لاگین
        QNetworkRequest request(url);
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

        // ساخت داده‌ها به صورت JSON
        QJsonObject json;
        json["username"] = username;
        json["password"] = password;

        QJsonDocument doc(json);
        QByteArray data = doc.toJson();

        // ارسال درخواست به سرور
        QNetworkReply *reply = networkManager->post(request, data);
        connect(reply, &QNetworkReply::finished, this, &ServerClientCommunication::onResponseReceived);
    }

    // ارسال داده‌ها برای تغییر رمز عبور
    void sendChangePasswordRequest(const QString &userId, const QString &oldPassword, const QString &newPassword) {
        QUrl url("https://your-server-url.com/changePassword");
        QNetworkRequest request(url);
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

        // ساخت داده‌ها به صورت JSON
        QJsonObject json;
        json["userId"] = userId;
        json["oldPassword"] = oldPassword;
        json["newPassword"] = newPassword;

        QJsonDocument doc(json);
        QByteArray data = doc.toJson();

        // ارسال درخواست به سرور
        QNetworkReply *reply = networkManager->post(request, data);
        connect(reply, &QNetworkReply::finished, this, &ServerClientCommunication::onResponseReceived);
    }

    // ارسال داده‌ها برای ایجاد ولت
    void sendCreateWalletRequest(const QString &userId, const QString &walletName) {
        QUrl url("https://your-server-url.com/createWallet");
        QNetworkRequest request(url);
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

        // ساخت داده‌ها به صورت JSON
        QJsonObject json;
        json["userId"] = userId;
        json["walletName"] = walletName;

        QJsonDocument doc(json);
        QByteArray data = doc.toJson();

        // ارسال درخواست به سرور
        QNetworkReply *reply = networkManager->post(request, data);
        connect(reply, &QNetworkReply::finished, this, &ServerClientCommunication::onResponseReceived);
    }

    void sendTransactionRequest(int senderWalletId, int receiverWalletId, double amount, const QString &currency) {
        QUrl url("https://your-server-url.com/transaction");
        QNetworkRequest request(url);
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

        // ساخت داده‌ها به صورت JSON
        QJsonObject json;
        json["senderWalletId"] = senderWalletId;
        json["receiverWalletId"] = receiverWalletId;
        json["amount"] = amount;
        json["currency"] = currency;

        QJsonDocument doc(json);
        QByteArray data = doc.toJson();

        // ارسال درخواست به سرور
        QNetworkReply *reply = networkManager->post(request, data);
        connect(reply, &QNetworkReply::finished, this, &ServerClientCommunication::onResponseReceived);
    }

private slots:
    // این متد وقتی داده‌ها از سرور دریافت می‌شود، فراخوانی می‌شود
    void onResponseReceived() {
        QNetworkReply *reply = qobject_cast<QNetworkReply *>(sender());
        if (!reply) return;

        if (reply->error() != QNetworkReply::NoError) {
            qDebug() << "Error:" << reply->errorString();
            return;
        }

        // دریافت پاسخ سرور به صورت JSON
        QByteArray responseData = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(responseData);
        QJsonObject jsonResponse = doc.object();

        // بررسی و پردازش پاسخ از سرور
        qDebug() << "Response from server:" << jsonResponse;
        emit responseReceived(jsonResponse);

        reply->deleteLater();
    }

signals:
    // سیگنالی برای ارسال پاسخ دریافت شده به کلاینت
    void responseReceived(const QJsonObject &response);

private:
    QNetworkAccessManager *networkManager;  // مدیریت ارسال درخواست‌ها
};
