#include <QString>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include "UserException.h"

class WalletValidation {
public:
    WalletValidation(QSqlDatabase &db) : database(db) {}

    // اعتبارسنجی نام ولت
    void validateWalletName(const QString &walletName, int userId) {
        if (walletName.isEmpty()) {
            throw UserException("Wallet name cannot be empty");
        }

        if (walletExists(walletName, userId)) {
            throw UserException("Wallet name already exists");
        }
    }

private:
    QSqlDatabase database;

    // بررسی وجود نام ولت برای کاربر
    bool walletExists(const QString &walletName, int userId) {
        QSqlQuery query(database);
        query.prepare("SELECT COUNT(*) FROM wallets WHERE name = :name AND user_id = :userId");
        query.bindValue(":name", walletName);
        query.bindValue(":userId", userId);

        if (query.exec() && query.next()) {
            return query.value(0).toInt() > 0;
        }

        throw UserException("Failed to check wallet existence: " + query.lastError().text());
    }
};
