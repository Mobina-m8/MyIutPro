#include <QSqlQuery>
#include <QSqlError>
#include <QCryptographicHash>
#include <QUuid>
#include <QDebug>
#include "UserValidation.h"
#include "UserException.h"

class UserManager {
public:
    UserManager(QSqlDatabase &db) : database(db), validator(db) {}

    // ثبت‌نام کاربر
    bool registerUser(const QString &email, const QString &password, const QString &name = "",
                      const QString &address = "", const QString &phone = "", const QString &inviteCode = "") {
        try {
            // ولید کردن اطلاعات کاربر
            if (!validator.validateUserData(email, password, phone)) {
                throw UserException("Invalid user data");
            }

            // چک کردن وجود کاربر
            if (userExists(email)) {
                throw UserException("User already exists");
            }

            // هش کردن پسورد
            QString hashedPassword = hashPassword(password);

            // ایجاد کد دعوت
            QString generatedInviteCode = QUuid::createUuid().toString(QUuid::WithoutBraces);

            // افزودن کاربر به دیتابیس
            QSqlQuery query(database);
            query.prepare(R"(
                INSERT INTO users (email, password, name, address, phone, invite_code)
                VALUES (:email, :password, :name, :address, :phone, :invite_code);
            )");
            query.bindValue(":email", email);
            query.bindValue(":password", hashedPassword);
            query.bindValue(":name", name);
            query.bindValue(":address", address);
            query.bindValue(":phone", phone);
            query.bindValue(":invite_code", generatedInviteCode);

            if (!query.exec()) {
                throw UserException("Failed to register user: " + query.lastError().text());
            }

            qDebug() << "User registered successfully.";
            return true;
        } catch (const UserException &e) {
            qDebug() << "Error:" << e.what();
            throw; // خطا را به کلاینت ارسال کنید
        }
    }

    // ورود کاربر
    bool loginUser(const QString &email, const QString &password) {
        try {
            QString hashedPassword = hashPassword(password);

            QSqlQuery query(database);
            query.prepare(R"(
                SELECT id FROM users WHERE email = :email AND password = :password;
            )");
            query.bindValue(":email", email);
            query.bindValue(":password", hashedPassword);

            if (query.exec() && query.next()) {
                qDebug() << "Login successful for user ID:" << query.value(0).toInt();
                return true;
            } else {
                throw UserException("Invalid email or password");
            }
        } catch (const UserException &e) {
            qDebug() << "Error:" << e.what();
            throw;
        }
    }

    // تغییر رمز عبور
    bool changePassword(const QString &email, const QString &newPassword) {
        try {
            // بررسی قدرت رمز عبور
            validator.validatePassword(newPassword);

            // هش کردن رمز عبور
            QString hashedPassword = hashPassword(newPassword);

            // به‌روزرسانی رمز عبور در دیتابیس
            QSqlQuery query(database);
            query.prepare(R"(
                UPDATE users SET password = :password WHERE email = :email;
            )");
            query.bindValue(":password", hashedPassword);
            query.bindValue(":email", email);

            if (!query.exec()) {
                throw UserException("Failed to update password: " + query.lastError().text());
            }

            qDebug() << "Password changed successfully.";
            return true;
        } catch (const UserException &e) {
            qDebug() << "Error:" << e.what();
            throw;
        }
    }
    // احراز هویت کاربر
    bool verifyUser(const QString &email, const QString &verificationCode) {
        try {
            QSqlQuery query(database);
            query.prepare(R"(
                SELECT is_verified FROM users WHERE email = :email AND invite_code = :verificationCode;
            )");
            query.bindValue(":email", email);
            query.bindValue(":verificationCode", verificationCode);

            if (query.exec() && query.next()) {
                if (query.value(0).toInt() == 0) { // کاربر هنوز احراز هویت نشده است
                    // به‌روزرسانی وضعیت احراز هویت
                    QSqlQuery updateQuery(database);
                    updateQuery.prepare(R"(
                        UPDATE users SET is_verified = 1 WHERE email = :email;
                    )");
                    updateQuery.bindValue(":email", email);

                    if (!updateQuery.exec()) {
                        throw UserException("Failed to verify user: " + updateQuery.lastError().text());
                    }

                    qDebug() << "User verified successfully.";
                    return true;
                } else {
                    throw UserException("User is already verified");
                }
            }

            throw UserException("Invalid email or verification code");
        } catch (const UserException &e) {
            qDebug() << "Error:" << e.what();
            throw;
        }
    }

private:
    QSqlDatabase database;
    UserValidation validator;

    // هش کردن رمز عبور
    QString hashPassword(const QString &password) {
        return QString(QCryptographicHash::hash(password.toUtf8(), QCryptographicHash::Sha256).toHex());
    }

    // بررسی وجود کاربر
    bool userExists(const QString &email) {
        QSqlQuery query(database);
        query.prepare("SELECT COUNT(*) FROM users WHERE email = :email");
        query.bindValue(":email", email);

        if (query.exec() && query.next()) {
            return query.value(0).toInt() > 0;
        }

        throw UserException("Failed to check user existence: " + query.lastError().text());
    }
};
