#include "TransactionValidation.h"
#include "UserException.h"

// بررسی موجودی کافی برای خرید
bool TransactionValidation::validatePurchase(int walletId, const QString &currencyId, double amount, double price) {
    Wallet *wallet = walletManager->getWalletById(walletId);
    double usdtBalance = wallet->getBalance("usdt");

    if (usdtBalance < amount * price) {
        throw UserException("Insufficient USDT balance for purchase");
    }
    return true;
}

// بررسی موجودی کافی برای فروش
bool TransactionValidation::validateSell(int walletId, const QString &currencyId, double amount) {
    Wallet *wallet = walletManager->getWalletById(walletId);
    double currencyBalance = wallet->getBalance(currencyId);

    if (currencyBalance < amount) {
        throw UserException("Insufficient " + currencyId + " balance for sell");
    }
    return true;
}

// بررسی موجودی کافی برای انتقال ارز
bool TransactionValidation::validateTransfer(int walletId, const QString &currencyId, double amount) {
    Wallet *wallet = walletManager->getWalletById(walletId);
    double balance = wallet->getBalance(currencyId);

    if (balance < amount) {
        throw UserException("Insufficient balance for transfer");
    }
    return true;
}
